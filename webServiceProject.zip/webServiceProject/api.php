<?php

$host = 'localhost';
$dbname = 'webservice';
$user = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}

$stmt = $pdo->query("SELECT * FROM flights");
$flights = $stmt->fetchAll(PDO::FETCH_ASSOC);

$response = [
    'status' => 1,
    'message' => 'Success',
    'data' => $flights,
    'timestamp' => time(),
];

header('Content-Type: application/json');
echo json_encode($response);

