<nav class="main-header navbar navbar-expand navbar-white navbar-light">
  <!-- Left navbar links -->


  <!-- Right navbar links -->
  <ul class="navbar-nav ml-auto">
    <!-- Navbar Search -->
    <li class="nav-item">

      <a class="nav-link" href="index.php" role="button">
        <i class="fas fa-sign-out-alt"></i>
      </a>

    </li>
    <li class="nav-item">

      <a class="nav-link" data-widget="fullscreen" href="#" role="button">
        <i class="fas fa-expand-arrows-alt"></i>
      </a>

    </li>

  </ul>
</nav>