<footer class="main-footer">
    <strong> &copy; 2023 <a href="https://haramayauniversity.edu.et">Online flight hotel and weather searching appilication</a>.</strong>
    by SWE 5th year students
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 1.0
    </div>
  </footer>