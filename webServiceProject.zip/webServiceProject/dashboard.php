<?php


    $apiUrl = 'http://localhost/webserviceproject/api.php';
    $response = file_get_contents($apiUrl);
    $data = json_decode($response, true);

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Flight Information</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <link rel="stylesheet" href="UI/plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="UI/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <link rel="stylesheet" href="UI/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <link rel="stylesheet" href="UI/plugins/jqvmap/jqvmap.min.css">
  <link rel="stylesheet" href="UI/dist/css/adminlte.min.css">
  <link rel="stylesheet" href="UI/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <link rel="stylesheet" href="UI/plugins/daterangepicker/daterangepicker.css">
  <link rel="stylesheet" href="UI/plugins/summernote/summernote-bs4.min.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">


  <div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__shake" src="images/logo.jpg" alt="AdminLTELogo" height="60" width="60">
  </div>


 <?php include 'layouts/header.php'; ?>

 
  <?php include 'layouts/sidebar.php'; ?>


  <div class="content-wrapper">
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Local Flight Data</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div>
        </div>
      </div>
    </div>

    <section class="content">
      <div class="container-fluid">
        <div class="row">
        <?php
            if ($data['status'] === 1) {
        
                $destinations = $data['data'];

                if (!empty($destinations)) {
                    foreach ($destinations as $destination) {
                        ?>
                        <div class="col-md-4">
                            <div class="card p-4 shadow-lg ">
                                <h4 style="font-weight: 700;"><u>Flight Name:</u> <?php echo $destination['flight_name'] ?></h4>
                                <p>From: <?php echo $destination['from_location']; ?></p>
                                <p>To: <?php echo $destination['to_location']; ?></p>  
                                <p>Price: <?php echo $destination['price']."birr"; ?></p>    

                            </div>
                        </div>
                        <?php
                    }
                } else {
                    echo 'No destinations available.';
                }
            } else {

                echo 'Error: ' . $data['message'];
            }
            ?>
          
        </div>
     
      </div>
    </section>

  </div>
  <?php include 'layouts/footer.php'; ?>
</div>
        </div>
<script src="UI/plugins/jquery/jquery.min.js"></script>
<script src="UI/plugins/jquery-ui/jquery-ui.min.js"></script>
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<script src="UI/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="UI/plugins/chart.js/Chart.min.js"></script>
<script src="UI/plugins/sparklines/sparkline.js"></script>
<script src="UI/plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="UI/plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<script src="UI/plugins/jquery-knob/jquery.knob.min.js"></script>
<script src="UI/plugins/moment/moment.min.js"></script>
<script src="UI/plugins/daterangepicker/daterangepicker.js"></script>
<script src="UI/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<script src="UI//summernote/summernote-bs4.min.js"></script>
<script src="UI/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<script src="UI/dist/js/adminlte.js"></script>
<script src="UI/dist/js/pages/dashboard.js"></script>
</body>
</html>

