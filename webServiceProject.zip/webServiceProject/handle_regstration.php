<?php
// Connect to your MySQL database
$db = new mysqli('localhost', 'root', '', 'webservice');

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

// Handle registration
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['pass'], PASSWORD_DEFAULT);


    $stmt = $db->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param('sss', $username, $email,  $password);

    if ($stmt->execute()) {
        header('Location: login.php');
    } else {
        echo json_encode(['message' => 'Registration failed']);
    }

    $stmt->close();
} else {
    echo json_encode(['message' => 'Invalid request method']);
}

$db->close();
