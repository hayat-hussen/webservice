<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {


    $curl = curl_init();

    $from = isset($_POST['from']) ? $_POST['from'] : '';

    curl_setopt_array($curl, [
        CURLOPT_URL => "https://tripadvisor16.p.rapidapi.com/api/v1/flights/searchAirport?query={$from}",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => [
            "X-RapidAPI-Host: tripadvisor16.p.rapidapi.com",
            "X-RapidAPI-Key: aaef2857b3msh34e64b629861d57p1be8d1jsne69c91ffaedd"
        ],
    ]);
    
    $response = curl_exec($curl);
    $err = curl_error($curl);
    
    curl_close($curl);
    
    if ($err) {
        echo "cURL Error #:" . $err;
    } else {
    
        $flight_data = json_decode($response, true);
    
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Flight Information</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="UI/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="UI/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="UI/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="UI/plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="UI/dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="UI/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="UI/plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="UI/plugins/summernote/summernote-bs4.min.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Preloader -->
  <div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__shake" src="images/logo.jpg" alt="AdminLTELogo" height="60" width="60">
  </div>


  <!-- Navbar -->
 <?php include 'layouts/header.php'; ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
 
  <?php include 'layouts/sidebar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          

        <?php
        // Loop through the API results and display them
        foreach ($flight_data['data'] as $flight) {
            ?>
            <div class="col-md-4">
                <div class="card p-4 shadow-lg ">
                    <h4 style="font-weight: 700;"><u>Flight Name:</u> <?php echo $flight['details']['name']; ?></h4>
                    <p>From: <?php echo $flight['details']['grandparent_name']; ?></p>
                    <p>To: <?php echo $flight['details']['parent_name']; ?></p>    
                </div>
            </div>
            <?php
        }
        ?>


        
        </div>
     
      </div>
    </section>
  </div>
  
  <?php include 'layouts/footer.php'; ?>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>


<script src="UI/plugins/jquery/jquery.min.js"></script>
<script src="UI/plugins/jquery-ui/jquery-ui.min.js"></script>

<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<script src="UI/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="UI/plugins/chart.js/Chart.min.js"></script>
<script src="UI/plugins/sparklines/sparkline.js"></script>
<script src="UI/plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="UI/plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<script src="UI/plugins/jquery-knob/jquery.knob.min.js"></script>
<script src="UI/plugins/moment/moment.min.js"></script>
<script src="UI/plugins/daterangepicker/daterangepicker.js"></script>
<script src="UI/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<script src="UI//summernote/summernote-bs4.min.js"></script>
<script src="UI/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<script src="UI/dist/js/adminlte.js"></script>
<script src="UI/dist/js/pages/dashboard.js"></script>
</body>
</html>


