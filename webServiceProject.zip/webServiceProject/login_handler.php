<?php

$db = new mysqli('localhost', 'root', '', 'webservice');

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $db->prepare("SELECT id, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($id, $hashedPassword);

    if ($stmt->fetch() && password_verify($password, $hashedPassword)) {
        header('Location: dashboard.php');
    } else {
        echo json_encode(['message' => 'Login failed']);
    }

    $stmt->close();
} else {
    echo json_encode(['message' => 'Invalid request method']);
}

$db->close();
