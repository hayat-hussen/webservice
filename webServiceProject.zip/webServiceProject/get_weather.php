<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $apiKey = '55399e33183671f58ab8df1dadaf529d';

    $cityName = isset($_POST['wethercity']) ? $_POST['wethercity'] : '';

    $apiEndpoint = "http://api.openweathermap.org/data/2.5/weather?q={$cityName}&appid={$apiKey}";



    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $apiEndpoint);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        echo 'Error: ' . curl_error($ch);
    } else {
        $weatherData = json_decode($response, true);

        if ($weatherData['cod'] == 200) {
            $temperature = $weatherData['main']['temp'];
            $humudity = $weatherData['main']['humidity'];
            $pressure = $weatherData['main']['pressure'];
            $description = $weatherData['weather'][0]['description'];
            $windspeed = $weatherData['wind']['speed'];

            $floatval = (float)$temperature;
    
            $temp = $floatval - 273;
    
        } else {
            echo 'Error: ' . $weatherData['message'];
         
        }
    }

    curl_close($ch);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Weather information</title>

  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <link rel="stylesheet" href="UI/plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="UI/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <link rel="stylesheet" href="UI/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <link rel="stylesheet" href="UI/plugins/jqvmap/jqvmap.min.css">
  <link rel="stylesheet" href="UI/dist/css/adminlte.min.css">
  <link rel="stylesheet" href="UI/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <link rel="stylesheet" href="UI/plugins/daterangepicker/daterangepicker.css">
  <link rel="stylesheet" href="UI/plugins/summernote/summernote-bs4.min.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__shake" src="images/logo.jpg" alt="AdminLTELogo" height="60" width="60">
  </div>


 <?php include 'layouts/header.php'; ?>

 
  <?php include 'layouts/sidebar.php'; ?>

  <div class="content-wrapper">
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
    
    <section class="content">
      <div class="container-fluid">
        <div class="row">
         
        
        <section class="col-md-12">
        <div class="container py-5 h-150">

            <div class="row d-flex justify-content-center align-items-center h-100">
            <div class="col-md-8 col-lg-6 col-xl-6">

                <div class="card" style="color: #4B515D; border-radius: 35px;">
                <div class="card-body p-4">

                    <div class="d-flex">
                    <h6 class="flex-grow-1"><?php echo $_POST['wethercity'] ?></h6>
                    <h6><?php echo date("H:i"); ?></h6>
                    </div>

                    <div class="d-flex flex-column text-center mt-5 mb-4">
                    <h6 class="display-4 mb-0 font-weight-bold" style="color: #1C2331;"><?php echo $temp ?> </h6>
                    <span class="small" style="color: #868B94"><?php echo $description?></span> 
                    </div>

                    <div class="d-flex align-items-center">
                    <div class="flex-grow-1" style="font-size: 1rem;">
                        <div><i class="fas fa-wind fa-fw" style="color: #868B94;"></i> <span class="ms-1"> <?php echo $windspeed ?>
                        </span></div>
                        <div><i class="fas fa-tint fa-fw" style="color: #868B94;"></i> <span class="ms-1"> <?php echo $humudity ?>%  </span>
                        </div>
                        <div><i class="fas fa-sun fa-fw" style="color: #868B94;"></i> <span class="ms-1"><?php echo $pressure ?>hpa </span>
                        </div>
                    </div>
                    <div>
                        <?php if ($temp <=20 )
                         echo "<img src='images/cloud.png'
                        width='100px'>";
                        elseif($temp>20){
                            echo  "<img src='images/sunny.jpg'
                            width='100px'>";
                        }

                        ?>
                      
                        
                    </div>
                    </div>

                </div>
                </div>

            </div>
            </div>
        </div>
        </section>
        </div>
      </div>
    </section>
  </div>
  <?php include 'layouts/footer.php'; ?>

  <aside class="control-sidebar control-sidebar-dark">
  </aside>
</div>
<script src="UI/plugins/jquery/jquery.min.js"></script>
<script src="UI/plugins/jquery-ui/jquery-ui.min.js"></script>
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<script src="UI/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="UI/plugins/chart.js/Chart.min.js"></script>
<script src="UI/plugins/sparklines/sparkline.js"></script>
<script src="UI/plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="UI/plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<script src="UI/plugins/jquery-knob/jquery.knob.min.js"></script>
<script src="UI/plugins/moment/moment.min.js"></script>
<script src="UI/plugins/daterangepicker/daterangepicker.js"></script>
<script src="UI/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<script src="UI//summernote/summernote-bs4.min.js"></script>
<script src="UI/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<script src="UI/dist/js/adminlte.js"></script>
<script src="UI/dist/js/pages/dashboard.js"></script>
</body>
</html>
